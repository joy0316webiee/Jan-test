const API_URL = "https://reqres.in/api";
const USER_LIMIT = 15;

export { API_URL, USER_LIMIT };
